#include "Shape.h"
#ifndef CHONHINH_H_
#define CHONHINH_H_

class ChonHinh {

};

#endif // !CHONHINH_H_
